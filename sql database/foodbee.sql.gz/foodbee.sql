-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 19, 2021 at 12:47 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `foodbee`
--

-- --------------------------------------------------------

--
-- Table structure for table `account`
--

CREATE TABLE `account` (
  `username` varchar(20) NOT NULL,
  `name` varchar(50) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `pass` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `account`
--

INSERT INTO `account` (`username`, `name`, `phone`, `pass`) VALUES
('jubair', 'Jubair Faisal', '0175234404', '111555'),
('nishat', 'Nishat Tasnim', '0175234404', '111555'),
('rahat', 'Ashraf Ullah Rahat', '019122323', '111555'),
('shaikh', 'Abdullah Al Shaikh', '01824050513', '111555');

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `userid` varchar(20) NOT NULL,
  `pass` varchar(20) NOT NULL,
  `name` varchar(50) NOT NULL,
  `dp` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`userid`, `pass`, `name`, `dp`) VALUES
('foodbee1', '555666', 'Abdullah Al Shaikh', 'uploads/adm1.png'),
('foodbee2', '555666', 'Nishat Tasnim', 'uploads/adm2.png'),
('foodbee3', '555666', 'Jubair Faisal', 'uploads/adm3.png'),
('foodbee4', '555666', 'Ashraf Ullah Rahat', 'uploads/adm4.png');

-- --------------------------------------------------------

--
-- Table structure for table `fooddetail`
--

CREATE TABLE `fooddetail` (
  `food_id` varchar(20) NOT NULL,
  `food_name` varchar(100) NOT NULL,
  `food_type` varchar(100) NOT NULL,
  `food_cuisine` varchar(100) NOT NULL,
  `food_price` int(11) NOT NULL,
  `max_quantity` int(11) NOT NULL,
  `restaurant_id` varchar(20) NOT NULL,
  `food_img` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `fooddetail`
--

INSERT INTO `fooddetail` (`food_id`, `food_name`, `food_type`, `food_cuisine`, `food_price`, `max_quantity`, `restaurant_id`, `food_img`) VALUES
('burger1', 'Chicken Burger ', 'Burger', 'Snacks', 250, 200, 'utr4', 'uploads/utr4food1.jpg'),
('d1f1', 'Strawberry Bread', 'Bread', 'Snacks', 100, 100, 'dhan1', 'uploads/anna_tukhfatullina_food_photographer_stylist_Mzy_OjtCI70_unsplash.jpg'),
('d1f2', 'Sushi Package ', 'Sushi', 'Lunch', 160, 100, 'dhan1', 'uploads/fadya-azhary-5KS7T3Gs3CA-unsplash.jpg'),
('d1f3', 'Dark Chocolate Muffin', 'Chocolate', 'Snacks', 100, 100, 'dhan1', 'uploads/heather-barnes-gP1YecpRyD8-unsplash.jpg'),
('d2f1', 'Spicy Ramen', 'Ramen', 'Lunch', 160, 100, 'dhan2', 'uploads/hari-panicker-2t28IxSTqF4-unsplash.jpg'),
('d2f2', 'BBQ Steak', 'Steak', 'Lunch', 200, 100, 'dhan2', 'uploads/hanxiao-zzxqoEa64_0-unsplash.jpg'),
('d2f3', 'Veg Chicken Pizza', 'Pizza ', 'Lunch', 1200, 100, 'dhan2', 'uploads/karthik-garikapati-oBbTc1VoT-0-unsplash.jpg'),
('d3f1', 'Keto Pack', 'Keto', 'Lunch', 160, 100, 'dhan3', 'uploads/logan-jeffrey-_QzzOnePrRw-unsplash.jpg'),
('d3f2', 'Vegetable Platter ', 'Keto', 'Lunch', 100, 100, 'dhan3', 'uploads/hermes-rivera-OzBLe_Eg1mg-unsplash.jpg'),
('d3f3', 'Mentha Drinks', 'Drinks', 'Drinks', 100, 100, 'dhan3', 'uploads/massimo-rinaldi-FmgZ5xzDG-s-unsplash.jpg'),
('d3f4', 'Chocolate Espresso ', 'Drinks Espresso', 'Drinks', 160, 100, 'dhan3', 'uploads/nathan-dumlao-c2Y16tC3yO8-unsplash.jpg'),
('d4f1', 'Thai Rice Curry', 'Thai Curry', 'Lunch', 130, 100, 'dhan4', 'uploads/pexels-buenosia-carol-674574.jpg'),
('d4f2', 'Thai Special Pasta', 'Pasta', 'Snacks', 160, 100, 'dhan4', 'uploads/pexels-engin-akyurt-1437267.jpg'),
('d5f1', 'Milk Fruits', 'Fruits', 'Lunch', 160, 100, 'dhan5', 'uploads/hanny-naibaho-6JUjdlHyqw0-unsplash.jpg'),
('d5f2', 'Oreo Milk Shake', 'Drinks', 'Drinks', 200, 100, 'dhan5', 'uploads/emile-mbunzama-cLpdEA23Z44-unsplash.jpg'),
('d5f3', 'Herbs Tea', 'Drinks', 'Drinks', 50, 100, 'dhan5', 'uploads/brigitte-tohm-EAay7Aj4jbc-unsplash.jpg'),
('m1f1', 'Mutton Curry ', 'Mutton', 'Lunch', 200, 100, 'mir1', 'uploads/sanket-shah-eEWlcfydzQ4-unsplash.jpg'),
('m1f2', 'Vegetable Steak ', 'Steak', 'Lunch', 400, 100, 'mir1', 'uploads/sam-moqadam-wg551YMfeOc-unsplash.jpg'),
('m1f3', 'Beef Curry', 'Beef ', 'Lunch', 300, 100, 'mir1', 'uploads/taylor-kiser-POFG828-GQc-unsplash.jpg'),
('m2f2', 'Mini Burger Pack', 'Burger', 'Lunch', 300, 100, 'mir2', 'uploads/umesh-soni-g1qlhFbWPKg-unsplash.jpg'),
('m2f22', 'Big Burger', 'Burger', 'Lunch', 300, 100, 'mir2', 'uploads/sk-CK6tjAIMJWM-unsplash.jpg'),
('m2f3', 'Double Cheese Buger', 'Burger', 'Lunch', 200, 100, 'mir2', 'uploads/pablo-merchan-montes-hyIE90CN6b0-unsplash.jpg'),
('m3f1', 'Naga Pizza', 'Pizza ', 'Lunch', 700, 100, 'mir3', 'uploads/nicolas-perondi-UxRhrU8fPHQ-unsplash.jpg'),
('m3f2', 'Spicy Smashed Chicken', 'Chicken', 'Lunch', 300, 100, 'mir3', 'uploads/nisha-ramesh-Q5mPPGld5Zk-unsplash.jpg'),
('m3f3', 'BBQ Beef ', 'Steak', 'Lunch', 400, 100, 'mir3', 'uploads/paul-hermann-jeiqzOgwwKU-unsplash.jpg'),
('m3f4', 'Spicy Pasta', 'Pasta', 'Snacks', 160, 100, 'mir3', 'uploads/stories-v1rUvnVMMkM-unsplash.jpg'),
('m4f1', 'Special Veg Fry', 'Veg', 'Lunch', 160, 100, 'mir4', 'uploads/sigmund-nHq5a_XbIZ0-unsplash.jpg'),
('m4f2', 'Mutton Veg Curry ', 'Beef', 'Lunch', 400, 100, 'mir4', 'uploads/sigmund-akfDvDi6Wt4-unsplash.jpg'),
('m4f3', 'Vegetable Chicken Fry ', 'Chicken', 'Lunch', 200, 100, 'mir4', 'uploads/sam-moqadam-LUv656869_A-unsplash.jpg'),
('m4f4', 'Broccoli Fry ', 'Vegetable', 'Lunch', 100, 100, 'mir4', 'uploads/sam-hojati-M4hazNIyTsk-unsplash.jpg'),
('m5f1', 'Egg Veg Momo', 'Egg', 'Lunch', 200, 100, 'mir5', 'uploads/quino-al-9P9VfiAHzr0-unsplash.jpg'),
('m5f2', 'Strawberry Icecream', 'Icecream', 'Snacks', 100, 100, 'mir5', 'uploads/pablo-merchan-montes-MXovqM130UI-unsplash.jpg'),
('m5f3', 'Espresso Light', 'Drinks', 'Drinks', 100, 100, 'mir5', 'uploads/nathan-dumlao-zUNs99PGDg0-unsplash.jpg'),
('m5f4', 'Chocolate Square ', 'Chocolate', 'Snacks', 160, 100, 'mir5', 'uploads/massimo-adami-JnqwC6dDL8c-unsplash.jpg'),
('muffin1', 'Chocolate Muffin', 'Muffin', 'Snacks, Dessert', 79, 100, 'utr1', 'uploads/utr1food4.jpg'),
('noodle1', 'Korean Noodles', 'Snacks', '', 150, 150, 'utr1', 'uploads/noodles.jpg'),
('noodles1', 'Chicken Noodles', 'Noodles', 'Snacks', 100, 200, 'utr1', 'uploads/utr1food1.jpg'),
('pasta1', 'Naga Pasta', 'Pasta', 'Snacks', 150, 200, 'utr1', 'uploads/pasta.jpg'),
('pizza1', 'Vegetable Pizza', 'Pizza', 'Lunch , Snacks', 1199, 50, 'utr1', 'uploads/utr1food3.jpg'),
('steak1', 'Beef Steak', 'Steak', 'Lunch, Dinner', 499, 20, 'utr1', 'uploads/utr1food2.jpg'),
('u3f1', 'Full Chicken', 'Grill', 'Lunch', 350, 40, 'utr3', 'uploads/claudio-schwarz-purzlbaum-cgcteFH-azk-unsplash.jpg'),
('u3f2', 'Chicken Nachos', 'Nachos', 'Snacks', 150, 150, 'utr3', 'uploads/clyde-gravenberch-mmHGXwhB7cE-unsplash.jpg'),
('u3f3', 'Chicken Noodle', 'Noodles', 'Snacks', 200, 40, 'utr3', 'uploads/jason-leung-AUAuEgUxg5Q-unsplash.jpg'),
('u4f1', 'Sushi ', 'Sushi', 'Lunch', 160, 100, 'utr5', 'uploads/derek-duran-Jz4QMhLvGgw-unsplash.jpg'),
('u4f2', 'Egg Special Bread', 'Bread', 'Snacks', 100, 100, 'utr4', 'uploads/eiliv-sonas-aceron-An6cTgmC8yk-unsplash.jpg'),
('u4f3', 'Bread Chicken', 'Bread', 'Snacks', 100, 100, 'utr4', 'uploads/eiliv-sonas-aceron-mAQZ3X_8_l0-unsplash.jpg'),
('u5f2', 'Strawberry Muffin', 'Muffin', 'Snacks', 100, 100, 'utr5', 'uploads/deva-williamson-S2jw81lfrG0-unsplash.jpg'),
('u5f3', 'Strawberry Milk Shake', 'Drinks', 'Drinks', 100, 100, 'utr5', 'uploads/dennis-klein-8oIo60aLztg-unsplash.jpg'),
('u5f4', 'Chocolate Platter', 'Chocolate', 'Snacks', 100, 100, 'utr5', 'uploads/artem-beliaikin-TSS-1aqoRXE-unsplash.jpg'),
('utr2food1', 'Beef Special Steak', 'Steak', 'Lunch', 250, 150, 'utr2', 'uploads/alexandru-bogdan-ghita-UeYkqQh4PoI-unsplash.jpg'),
('utr2food2', 'Chocolate n Juice', 'Dessert', 'Snacks', 100, 200, 'utr2', 'uploads/alireza-etemadi-JBIK4QZOFfc-unsplash.jpg'),
('utr2food3', '3deck Beef Burger', 'Burger', 'Snacks', 350, 200, 'utr2', 'uploads/amirali-mirhashemian-j-MPEwH9LM4-unsplash.jpg'),
('utr2food4', 'Double Layer Burger', 'Burger', 'Snacks', 250, 200, 'utr2', 'uploads/amirali-mirhashemian-sc5sTPMrVfk-unsplash.jpg'),
('utr2food5', 'Chicken Pasta', 'pasta', 'Snacks', 150, 200, 'utr2', 'uploads/andrea-davis-SXBVa3hioEc-unsplash.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `homemade`
--

CREATE TABLE `homemade` (
  `food_id` varchar(20) NOT NULL,
  `food_name` varchar(50) NOT NULL,
  `food_type` varchar(50) NOT NULL,
  `food_cuisine` varchar(50) NOT NULL,
  `food_price` varchar(20) NOT NULL,
  `food_img` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `homemade`
--

INSERT INTO `homemade` (`food_id`, `food_name`, `food_type`, `food_cuisine`, `food_price`, `food_img`) VALUES
('hmd1', 'Tanduri Chicken Biriyani', 'Biriyani', 'Lunch', '229', 'uploads/chicken biriyani.jpg'),
('hmd2', 'Special Vegetable Curry', 'Curry', 'Lunch', '59', 'uploads/special veg.jpg'),
('hmd3', 'BBQ Beef Steak', 'Steak', 'Lunch', '399', 'uploads/beef steak.jpg'),
('hmd4', 'Special Samucha', 'Samucha', 'Fast Foods', '29', 'uploads/samucha.jpg'),
('hmd5', 'Special Beef Steak', 'Steak', 'Lunch', '359', 'uploads/specila beef steak.jpg'),
('hmd6', 'Indian Luchi', 'Luchi', 'Snacks', '99', 'uploads/luchi.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `location`
--

CREATE TABLE `location` (
  `loc_code` varchar(20) NOT NULL,
  `location` varchar(100) NOT NULL,
  `area` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `location`
--

INSERT INTO `location` (`loc_code`, `location`, `area`) VALUES
('dhk1', 'Dhanmondi-10', 'Dhanmondi'),
('dhk10', 'Shonkor', 'Dhanmondi'),
('dhk11', 'Shayamoli', 'Shayamoli'),
('dhk12', 'Mohammadpur - Bus Stand', 'Mohammadpur'),
('dhk13', 'Mohammadpur - Katasur Bazar', 'Mohammadpur'),
('dhk14', 'Mohammadpur - Shia Masjid', 'Mohammadpur'),
('dhk15', 'Mirpur-1', 'Mirpur'),
('dhk16', 'Mirpur-2', 'Mirpur'),
('dhk17', 'Mirpur-10', 'Mirpur'),
('dhk18', 'Mirpur-14', 'Mirpur'),
('dhk19', 'Mirpur-11', 'Mirpur'),
('dhk2', 'Dhanmondi-15', 'Dhanmondi'),
('dhk20', 'Mirpur-12', 'Mirpur'),
('dhk21', 'Shewra Para', 'Mirpur'),
('dhk22', 'Shen Para', 'Mirpur'),
('dhk23', 'Uttara Sector-6', 'Uttara'),
('dhk24', 'Uttara Sector-8', 'Uttara'),
('dhk25', 'Abdullah Pur- Uttara', 'Uttara'),
('dhk26', 'Kamar Para - Uttara', 'Uttara'),
('dhk27', 'Uttara Sector-11', 'Uttara'),
('dhk28', 'Uttara Sector-12', 'Uttara'),
('dhk29', 'Uttara Sector-3', 'Uttara'),
('dhk3', 'Dhanmondi-27', 'Dhanmondi'),
('dhk30', 'Uttara Sector-4', 'Uttara'),
('dhk31', 'Khilgoan', 'Khilgaon'),
('dhk32', 'Bashabo - Khilgaon', 'Khilgaon'),
('dhk33', 'Rampura - Khilgaon', 'Khilgaon'),
('dhk34', 'Taltola - Khilgaon', 'Khilgaon'),
('dhk35', 'Shahjahanpur - Rajarbagh', 'Rajarbagh'),
('dhk36', 'Shantibag - Rajarbagh', 'Rajarbagh'),
('dhk37', 'Malibagh - Rajarbagh', 'Rajarbagh'),
('dhk38', 'Shantinagar - Rajarbagh', 'Rajarbagh'),
('dhk39', 'Rampura - Khilgaon', 'Khilgaon'),
('dhk4', 'Dhanmondi-11', 'Dhanmondi'),
('dhk40', 'Mogbazar - Tejgaon', 'Tejgaon'),
('dhk5', 'Dhanmondi-32', 'Dhanmondi'),
('dhk6', 'Dhanmondi-8', 'Dhanmondi'),
('dhk7', 'Jhigatola', 'Dhanmondi'),
('dhk8', 'Rayer Bazar', 'Dhanmondi'),
('dhk9', 'Hajaribagh', 'Dhanmondi');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `userid` varchar(30) NOT NULL,
  `food_id` varchar(30) NOT NULL,
  `res_id` varchar(30) NOT NULL,
  `status` varchar(30) NOT NULL,
  `amount` int(11) NOT NULL,
  `price` varchar(30) NOT NULL,
  `rating` varchar(30) NOT NULL,
  `review` varchar(500) NOT NULL,
  `location` varchar(200) NOT NULL,
  `time` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`userid`, `food_id`, `res_id`, `status`, `amount`, `price`, `rating`, `review`, `location`, `time`) VALUES
('shaikh', 'noodles1', 'utr1', '4', 2, '200', '4', 'Spicy', 'dha 2', '2021-04-16 19:26:30'),
('shaikh', 'pizza1', 'utr1', '4', 2, '2398', '4', 'It was spicy enough. One of the best.', 'Dhanmondi', '2021-04-16 20:47:23'),
('shaikh', 'burger1', 'utr4', '3', 2, '500', '', '', 'Hajaribagh', '2021-04-16 21:01:08'),
('shaikh', 'steak1', 'utr1', '2', 2, '998', '', '', 'Hajaribagh', '2021-04-17 09:28:09'),
('shaikh', 'muffin1', 'utr1', '3', 1, '79', '', '', 'Dhanmondi', '2021-04-18 11:18:52'),
('shaikh', 'burger1', 'utr4', '2', 3, '750', '', '', 'Shyamoli', '2021-04-18 12:00:05'),
('jubair', 'burger1', 'utr4', '3', 1, '250', '', '', 'Dhanmondi', '2021-04-18 12:16:58'),
('shaikh', 'noodle1', 'utr1', '2', 4, '600', '', '', 'Hajaribagh', '2021-04-19 15:13:07'),
('nishat', 'd3f3', 'dhan3', '4', 1, '100', '5', 'Healthy Drinks', 'Hajaribagh', '2021-04-19 16:34:44'),
('jubair', 'd3f3', 'dhan3', '4', 2, '200', '5', 'Nice Cold Drink. Good for health.', 'Gajipur', '2021-04-19 16:42:26');

-- --------------------------------------------------------

--
-- Table structure for table `restaurant`
--

CREATE TABLE `restaurant` (
  `restaurant_id` varchar(30) NOT NULL,
  `restaurant_name` varchar(100) NOT NULL,
  `area` varchar(100) NOT NULL,
  `manager_contact` varchar(200) NOT NULL,
  `available_time` varchar(100) NOT NULL,
  `restaurant_img` varchar(50) NOT NULL,
  `pass` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `restaurant`
--

INSERT INTO `restaurant` (`restaurant_id`, `restaurant_name`, `area`, `manager_contact`, `available_time`, `restaurant_img`, `pass`) VALUES
('dhan1', 'Chew & Cheer', 'Dhanmondi', 'Phn- 012242193218', '2PM - 9PM', 'uploads/dhan1.png', '111555'),
('dhan2', 'Super Sogbu', 'Dhanmondi', 'Phone - 01283343243', '10AM - 9PM', 'uploads/dhan2.png', '111555'),
('dhan3', 'Fomm Two', 'Dhanmondi', 'Manager \r\nPhone - 013828949354', '2PM - 12PM', 'uploads/dhan3.png', '111555'),
('dhan4', 'Thai Wan Kai', 'Dhanmondi', 'Phone - 012318378138', '12PM - 11PM', 'uploads/dhan4.png', '111555'),
('dhan5', 'Tia Alejandra', 'Dhanmondi', 'Phone - 012311243476', '11AM - 11PM', 'uploads/dhan5.png', '111555'),
('mir1', 'Sizzle Smoke', 'Mirpur', 'Phn- 0182842141242', '11AM - 10PM', 'uploads/mir.png', '111555'),
('mir2', 'Barga Bistro', 'Mirpur', 'Phone - 021341242', '11AM - 11PM', 'uploads/mir2.png', '111555'),
('mir3', 'Pablos Pepper', 'Mirpur', 'Phone - 0132813892174', '11AM - 11PM', 'uploads/mir3.png', '111555'),
('mir4', '22 Corner', 'Mirpur', 'Phone - 0132813892174', '11AM - 11PM', 'uploads/mir4.png', '111555'),
('mir5', 'Bistro Onyxe', 'Mirpur', 'Phone - 0132813892174', '11AM - 11PM', 'uploads/mir05.png', '111555'),
('utr1', 'Green Fresco', 'Uttara', 'Phn- 01828422', '11AM - 10PM', 'uploads/utr1.png', '111555'),
('utr2', 'Northern Solstice', 'Uttara', 'Phn- 01282193218', '11AM-12AM', 'uploads/utr2.png', '111555'),
('utr3', 'Roast Room', 'Uttara', 'Phn- 01433545518', '3PM - 10PM', 'uploads/utr3.png', '111555'),
('utr4', 'Burger King', 'Uttara', 'Phn- 053455193218', '2PM - 9PM', 'uploads/utr4.png', '111555'),
('utr5', 'Chefs Special', 'Uttara', 'Phn- 01282193218', '11AM-12AM', 'uploads/utr5.png', '111555');

-- --------------------------------------------------------

--
-- Table structure for table `riders`
--

CREATE TABLE `riders` (
  `rd_id` varchar(20) NOT NULL,
  `rd_name` varchar(100) NOT NULL,
  `rd_phone` varchar(20) NOT NULL,
  `rd_status` varchar(100) NOT NULL,
  `rd_image` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `riders`
--

INSERT INTO `riders` (`rd_id`, `rd_name`, `rd_phone`, `rd_status`, `rd_image`) VALUES
('rd1', 'Hasib Sorkar', '01824050513', '', 'uploads/utr10.png'),
('rd2', 'Jonayed Islam', '01824050513', '', 'uploads/meme2.png');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `account`
--
ALTER TABLE `account`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`userid`);

--
-- Indexes for table `fooddetail`
--
ALTER TABLE `fooddetail`
  ADD PRIMARY KEY (`food_id`);

--
-- Indexes for table `homemade`
--
ALTER TABLE `homemade`
  ADD PRIMARY KEY (`food_id`);

--
-- Indexes for table `location`
--
ALTER TABLE `location`
  ADD PRIMARY KEY (`loc_code`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`time`);

--
-- Indexes for table `restaurant`
--
ALTER TABLE `restaurant`
  ADD PRIMARY KEY (`restaurant_id`);

--
-- Indexes for table `riders`
--
ALTER TABLE `riders`
  ADD PRIMARY KEY (`rd_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
